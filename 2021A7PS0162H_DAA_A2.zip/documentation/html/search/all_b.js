var searchData=
[
  ['visualizer_0',['RNA Secondary Visualizer',['../index.html',1,'']]],
  ['vizualizer_1',['Running the Vizualizer',['../index.html#autotoc_md2',1,'']]]
];
