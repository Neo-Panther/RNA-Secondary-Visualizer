var searchData=
[
  ['the_20documentation_0',['Opening the Documentation',['../index.html#autotoc_md3',1,'']]],
  ['the_20vizualizer_1',['Running the Vizualizer',['../index.html#autotoc_md2',1,'']]]
];
