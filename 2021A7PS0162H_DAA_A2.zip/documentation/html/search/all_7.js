var searchData=
[
  ['opening_20the_20documentation_0',['Opening the Documentation',['../index.html#autotoc_md3',1,'']]]
];
