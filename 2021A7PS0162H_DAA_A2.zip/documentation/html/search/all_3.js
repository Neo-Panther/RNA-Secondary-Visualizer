var searchData=
[
  ['dependencies_20needed_0',['Dependencies Needed',['../index.html#autotoc_md1',1,'']]],
  ['documentation_1',['Opening the Documentation',['../index.html#autotoc_md3',1,'']]]
];
